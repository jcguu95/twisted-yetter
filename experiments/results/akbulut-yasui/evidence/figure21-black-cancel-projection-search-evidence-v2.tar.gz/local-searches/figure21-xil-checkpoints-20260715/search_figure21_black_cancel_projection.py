#!/usr/bin/env python3
"""Deterministic projection-direction searches for a fixed PL link."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import random
import time

from experiments.scripts.morse_pl_lift import (
    analyze_projection,
    lower_generic_projection_to_morse,
    make_generic_view_projection_lift,
    render_projection_svg,
)


def van_der_corput(index: int, base: int) -> float:
    result = 0.0
    denominator = 1.0
    while index:
        index, remainder = divmod(index, base)
        denominator *= base
        result += remainder / denominator
    return result


def candidates(strategy: str, count: int):
    if strategy == "micro-grid":
        rows = [
            (88.0 + 0.25 * i, 0.05 + 0.05 * j)
            for i in range(25)
            for j in range(20)
        ]
        return rows[:count]
    if strategy == "broad-halton":
        return [
            (180.0 * van_der_corput(i, 2), 0.05 + 29.95 * van_der_corput(i, 3))
            for i in range(1, count + 1)
        ]
    if strategy == "seeded-random":
        generator = random.Random(20260715)
        return [
            (180.0 * generator.random(), 0.05 + 29.95 * generator.random())
            for _ in range(count)
        ]
    if strategy == "near-edge-halton":
        return [
            (
                75.0 + 32.0 * van_der_corput(i, 2),
                0.01 * (500.0 ** van_der_corput(i, 5)),
            )
            for i in range(1, count + 1)
        ]
    if strategy == "lowerability-jitter":
        generator = random.Random(4774_20260715)
        rows = []
        for _ in range(count):
            angle_scale = 10.0 ** generator.uniform(-8.0, -2.0)
            tilt_scale = 10.0 ** generator.uniform(-8.0, -2.0)
            rows.append(
                (
                    90.25 + generator.choice((-1.0, 1.0)) * angle_scale,
                    0.25 + generator.choice((-1.0, 1.0)) * tilt_scale,
                )
            )
        return rows
    if strategy == "edge-lowerability-jitter":
        generator = random.Random(4234_20260715)
        rows = []
        for _ in range(count):
            angle_scale = 10.0 ** generator.uniform(-8.0, -2.0)
            tilt_scale = 10.0 ** generator.uniform(-10.0, -4.0)
            rows.append(
                (
                    86.875 + generator.choice((-1.0, 1.0)) * angle_scale,
                    0.010200858045999784
                    + generator.choice((-1.0, 1.0)) * tilt_scale,
                )
            )
        return rows
    if strategy == "edge-ultrafine-jitter":
        generator = random.Random(4231_20260715)
        rows = []
        for _ in range(count):
            angle_scale = 10.0 ** generator.uniform(-9.0, -3.0)
            tilt_scale = 10.0 ** generator.uniform(-11.0, -5.0)
            rows.append(
                (
                    86.87957953397661
                    + generator.choice((-1.0, 1.0)) * angle_scale,
                    0.01011336604237515
                    + generator.choice((-1.0, 1.0)) * tilt_scale,
                )
            )
        return rows
    if strategy == "edge-wide-neighborhood":
        generator = random.Random(4231_20260716)
        return [
            (
                86.87957953397661 + generator.uniform(-1.5, 1.5),
                0.01011336604237515 * (10.0 ** generator.uniform(-1.0, 1.0)),
            )
            for _ in range(count)
        ]
    if strategy == "edge-ridge-halton":
        return [
            (
                82.0 + 10.0 * van_der_corput(i, 2),
                0.002 * (100.0 ** van_der_corput(i, 3)),
            )
            for i in range(1, count + 1)
        ]
    if strategy == "lowtilt-lowerability-jitter":
        generator = random.Random(4054_20260715)
        rows = []
        for _ in range(count):
            angle_scale = 10.0 ** generator.uniform(-9.0, -3.0)
            tilt_scale = 10.0 ** generator.uniform(-12.0, -6.0)
            rows.append(
                (
                    85.96461934121956
                    + generator.choice((-1.0, 1.0)) * angle_scale,
                    0.0012281768480564424
                    + generator.choice((-1.0, 1.0)) * tilt_scale,
                )
            )
        return rows
    if strategy == "very-low-tilt-halton":
        return [
            (
                70.0 + 40.0 * van_der_corput(i, 2),
                0.0001 * (30.0 ** van_der_corput(i, 7)),
            )
            for i in range(1, count + 1)
        ]
    if strategy == "best3990-neighborhood":
        generator = random.Random(3990_20260715)
        return [
            (
                78.75 + generator.uniform(-5.0, 5.0),
                0.0001320022478803632 * (10.0 ** generator.uniform(-1.0, 1.0)),
            )
            for _ in range(count)
        ]
    if strategy == "ultralow-tilt-halton":
        return [
            (
                180.0 * van_der_corput(i, 2),
                0.000001 * (100.0 ** van_der_corput(i, 11)),
            )
            for i in range(1, count + 1)
        ]
    if strategy == "lowtilt-systematic-grid":
        angles = [60.0 + 0.4 * i for i in range(101)]
        tilts = [10.0 ** (-7.0 + 0.5 * j) for j in range(11)]
        return [(angle, tilt) for tilt in tilts for angle in angles][:count]
    if strategy == "lowtilt-log-random":
        generator = random.Random(3990_20260716)
        return [
            (
                180.0 * generator.random(),
                10.0 ** generator.uniform(-7.0, -2.0),
            )
            for _ in range(count)
        ]
    raise ValueError(f"unknown strategy {strategy}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--strategy", required=True)
    parser.add_argument("--count", type=int, default=500)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()
    args.output_root.mkdir(parents=True, exist_ok=True)
    source = json.loads(args.input.read_text())
    lift = source["lift"]
    candidate_rows = candidates(args.strategy, args.count)
    rows = []
    best = None
    started = time.perf_counter()
    checkpoint = args.output_root / "checkpoint.json"
    if checkpoint.exists():
        previous = json.loads(checkpoint.read_text())
        if (
            previous.get("strategy") == args.strategy
            and previous.get("source_lift_hash") == lift["lift_hash"]
            and previous.get("total") == len(candidate_rows)
        ):
            rows = list(previous.get("rows", ()))
            valid = [
                row for row in rows if row["unexplained_singularities"] == 0
            ]
            if valid:
                row = min(
                    valid,
                    key=lambda item: (
                        item["regular_crossings"], item["candidate_index"]
                    ),
                )
                best = (
                    row["regular_crossings"], row["candidate_index"],
                    row["angle_degrees"], row["tilt_degrees"], None,
                )
    completed_indices = {row["candidate_index"] for row in rows}
    for index, (angle, tilt) in enumerate(candidate_rows):
        if index in completed_indices:
            continue
        viewed = make_generic_view_projection_lift(
            lift,
            in_plane_angle_degrees=angle,
            tilt_degrees=tilt,
        )
        report = analyze_projection(viewed, "xz", max_examples=0)
        crossing_count = int(report["counts"].get("regular_double_point", 0))
        row = {
            "candidate_index": index,
            "angle_degrees": angle,
            "tilt_degrees": tilt,
            "regular_crossings": crossing_count,
            "unexplained_singularities": report["unexplained_singularity_count"],
            "status": report["status"],
        }
        rows.append(row)
        if report["unexplained_singularity_count"] == 0:
            candidate = (crossing_count, index, angle, tilt, viewed)
            if best is None or candidate[:2] < best[:2]:
                best = candidate
                print(json.dumps({"new_best": row}), flush=True)
        checkpoint.write_text(json.dumps({
            "schema": "twisted-yetter.figure21-black-cancel-projection-search.v1",
            "status": "RUNNING",
            "strategy": args.strategy,
            "source_lift_hash": lift["lift_hash"],
            "completed": len(rows),
            "total": len(candidate_rows),
            "best": None if best is None else {
                "regular_crossings": best[0],
                "candidate_index": best[1],
                "angle_degrees": best[2],
                "tilt_degrees": best[3],
            },
            "elapsed_seconds": time.perf_counter() - started,
            "rows": rows,
        }, indent=2, sort_keys=True) + "\n")
    if best is None:
        raise RuntimeError("search produced no generic projection")
    crossing_count, index, angle, tilt, viewed = best
    if viewed is None:
        viewed = make_generic_view_projection_lift(
            lift,
            in_plane_angle_degrees=angle,
            tilt_degrees=tilt,
        )
    svg = args.output_root / "best.svg"
    lowered_path = args.output_root / "best-lowered.json"
    metadata_path = args.output_root / "best-metadata.json"
    geometric_best = {
        "candidate_index": index,
        "angle_degrees": angle,
        "tilt_degrees": tilt,
        "regular_crossings": crossing_count,
    }
    lowering_failures = []
    lowered = None
    lowerable_row = None
    lowering_seconds = 0.0
    for row in sorted(
        (row for row in rows if row["unexplained_singularities"] == 0),
        key=lambda item: (item["regular_crossings"], item["candidate_index"]),
    ):
        candidate_view = make_generic_view_projection_lift(
            lift,
            in_plane_angle_degrees=row["angle_degrees"],
            tilt_degrees=row["tilt_degrees"],
        )
        lower_started = time.perf_counter()
        try:
            candidate_lowered = lower_generic_projection_to_morse(candidate_view)
        except ValueError as caught:
            lowering_failures.append({
                "candidate_index": row["candidate_index"],
                "regular_crossings": row["regular_crossings"],
                "angle_degrees": row["angle_degrees"],
                "tilt_degrees": row["tilt_degrees"],
                "error": str(caught),
            })
            continue
        lowering_seconds += time.perf_counter() - lower_started
        lowered = candidate_lowered
        lowerable_row = row
        viewed = candidate_view
        break
    if lowered is None or lowerable_row is None:
        raise RuntimeError("no searched generic projection could be lowered to Morse")
    crossing_count = lowerable_row["regular_crossings"]
    index = lowerable_row["candidate_index"]
    angle = lowerable_row["angle_degrees"]
    tilt = lowerable_row["tilt_degrees"]
    svg.write_text(render_projection_svg(viewed, "xz", width=2400))
    lowered_path.write_text(json.dumps(lowered, indent=2, sort_keys=True) + "\n")
    metadata = {
        "schema": "twisted-yetter.figure21-black-cancel-projection-search-result.v1",
        "status": "PASS",
        "strategy": args.strategy,
        "source_lift_hash": lift["lift_hash"],
        "component_order": source["component_order"],
        "total_framings": source["total_framings"],
        "best": {
            "candidate_index": index,
            "angle_degrees": angle,
            "tilt_degrees": tilt,
            "regular_crossings": crossing_count,
        },
        "geometric_best": geometric_best,
        "lowering_failures_before_best": lowering_failures,
        "lowering_hash": lowered["lowering_hash"],
        "form_count": len(lowered["forms"]),
        "lowering_seconds": lowering_seconds,
        "lowered_path": str(lowered_path),
        "svg": str(svg),
        "candidate_count": len(rows),
        "elapsed_seconds": time.perf_counter() - started,
    }
    metadata_path.write_text(json.dumps(metadata, indent=2, sort_keys=True) + "\n")
    checkpoint.write_text(json.dumps({
        "schema": "twisted-yetter.figure21-black-cancel-projection-search.v1",
        "status": "PASS",
        "strategy": args.strategy,
        "source_lift_hash": lift["lift_hash"],
        "completed": len(rows),
        "total": len(rows),
        "best": metadata["best"],
        "elapsed_seconds": time.perf_counter() - started,
        "rows": rows,
    }, indent=2, sort_keys=True) + "\n")
    print(json.dumps(metadata, indent=2, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
