#!/bin/bash
set -euo pipefail

SNAPSHOT_ROOT=/tmp/twisted-yetter-su2-2-direct-snapshot
PLAN=/tmp/figure21-su2-2-direct-frontier16-hetzner-plan-v1.json
WORK_ROOT=/tmp/figure21-su2-2-direct-frontier16-hetzner-controls-v1
UNIT_PREFIX=ty-figure21-su22-frontier
SHARD_COUNT=16
MAX_SECTOR_SECONDS=1800

mkdir -p "$WORK_ROOT"

for shard in $(seq 0 $((SHARD_COUNT - 1))); do
    unit=$(printf '%s-%02d' "$UNIT_PREFIX" "$shard")
    systemctl stop "$unit.service" 2>/dev/null || true
    systemd-run \
        --unit="$unit" \
        --collect \
        --property=Nice=5 \
        --property=WorkingDirectory="$SNAPSHOT_ROOT" \
        --setenv=HOME=/root \
        --setenv=PYTHONPATH="$SNAPSHOT_ROOT" \
        /usr/bin/sage --python \
        experiments/sage/figure21_su2_2_direct_side_projector.py \
        --run-ranked-plan "$PLAN" \
        --shard-index "$shard" \
        --work-root "$WORK_ROOT" \
        --max-sector-seconds "$MAX_SECTOR_SECONDS"
done

printf 'started_at=%s\n' "$(date --iso-8601=seconds)"
systemctl list-units --all "${UNIT_PREFIX}-*.service" --no-pager
