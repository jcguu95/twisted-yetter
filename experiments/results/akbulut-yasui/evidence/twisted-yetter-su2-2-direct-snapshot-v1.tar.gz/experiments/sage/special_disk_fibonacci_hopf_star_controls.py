#!/usr/bin/env python3
"""Locate the first valence where side-projector lowering loses ribbon data.

The controls are Hopf stars: one crossing-free special red circle links each
ordinary component once.  All ordinary components carry Fibonacci tau.  The
source modular killing-loop evaluation is compared with the geometric side
lift followed by a horizontal collective vacuum projector.
"""

from __future__ import annotations

from collections import defaultdict
from datetime import UTC, datetime
import json
from pathlib import Path
import subprocess
import time

from experiments.sage.morse_category_registry import build_restricted_su2_category
from experiments.sage.morse_fusion_evaluator import MorseEvaluator, analyze_topology
from experiments.sage.ribbon_graph_evaluator import RibbonGraphEvaluator
from experiments.scripts.morse_dsl import MorseBuilder
from experiments.scripts.morse_pl_lift import (
    build_blockwise_flat_side_lift,
    build_morse_pl_lift,
    lower_exact_side_projection_to_morse,
    make_exact_side_projection_lift,
    optimize_special_disk_sides,
)
from experiments.scripts.special_dotted_morphism import (
    build_vacuum_coupon_graph,
    compile_projected_morphism,
    replay_forms,
    stable_json_hash,
)


REPO = Path(__file__).resolve().parents[2]
OUTPUT = Path("/tmp/special-disk-fibonacci-hopf-star-controls-v1.json")
SIDE_PARAMETERS = {
    "bump_fraction": 0.06,
    "crossing_height_mode": "minimal-local",
    "crossing_margin": 0.001,
    "block_order_strategy": "projected-mean-descending",
    "block_order_angle_degrees": 110.0,
    "side_projection_angle_degrees": 70.0,
}
EXPECTED_TAU_VACUUM_RANKS = {1: 0, 2: 1, 3: 1, 4: 2, 5: 3}
EXPECTED_TAU_VACUUM_RANKS[6] = 5


def _json_safe(value):
    if isinstance(value, complex):
        return [value.real, value.imag]
    if isinstance(value, dict):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    return value


def build_hopf_star(valence: int) -> tuple[tuple[dict, ...], dict[str, str]]:
    """Return one special red unknot Hopf-linked with ``valence`` unknots."""

    if valence < 1:
        raise ValueError("Hopf-star valence must be positive")
    builder = MorseBuilder()
    # Avoid the evaluator's historical ``A*`` convention, where A1, A2, ...
    # denote pieces of one semantic component rather than separate circles.
    ordinary = [f"C{index}" for index in range(1, valence + 1)]
    builder.cup(ordinary[0], at="far-left")
    for previous, component in zip(ordinary, ordinary[1:]):
        builder.cup(
            component,
            between=(f"{previous}.left", f"{previous}.right"),
        )
    builder.cup("red1", at="far-right")

    # Move red.left across all right branches, then retrace the same route.
    # The over/under choice gives linking number +1 with every ordinary circle.
    for component in ordinary:
        builder.cross(over=f"{component}.right", under="red1.left")
    for component in reversed(ordinary):
        builder.cross(over="red1.left", under=f"{component}.right")

    builder.cap("red1")
    for component in reversed(ordinary):
        builder.cap(component)
    if builder.order:
        raise AssertionError(f"Hopf-star builder left active strands: {builder.order!r}")
    component_by_piece = {component: component for component in ordinary}
    component_by_piece["red1"] = "red"
    return tuple(builder.forms), component_by_piece


def build_hopf_winding(punctures: int) -> tuple[tuple[dict, ...], dict[str, str]]:
    """Return one ordinary circle passing through the red disk repeatedly."""

    if punctures < 1:
        raise ValueError("Hopf-winding puncture count must be positive")
    builder = MorseBuilder()
    builder.cup("C1", at="far-left")
    builder.cup("red1", at="far-right")
    for _index in range(punctures):
        builder.cross(over="C1.right", under="red1.left")
        builder.cross(over="red1.left", under="C1.right")
    builder.cap("red1")
    builder.cap("C1")
    if builder.order:
        raise AssertionError(
            f"Hopf-winding builder left active strands: {builder.order!r}"
        )
    return tuple(builder.forms), {"C1": "C1", "red1": "red"}


def build_layered_hopf_star(
    component_count: int,
    *,
    rounds: int = 1,
    extra_nearest_windings: int = 0,
) -> tuple[tuple[dict, ...], dict[str, str]]:
    """Return repeated star passes, optionally with extra C1 disk passes."""

    if component_count < 1 or rounds < 1 or extra_nearest_windings < 0:
        raise ValueError("invalid layered Hopf-star parameters")
    builder = MorseBuilder()
    ordinary = [f"C{index}" for index in range(1, component_count + 1)]
    builder.cup(ordinary[0], at="far-left")
    for previous, component in zip(ordinary, ordinary[1:]):
        builder.cup(
            component,
            between=(f"{previous}.left", f"{previous}.right"),
        )
    builder.cup("red1", at="far-right")
    for _round in range(rounds):
        for component in ordinary:
            builder.cross(over=f"{component}.right", under="red1.left")
        for component in reversed(ordinary):
            builder.cross(over="red1.left", under=f"{component}.right")
    for _extra in range(extra_nearest_windings):
        builder.cross(over="C1.right", under="red1.left")
        builder.cross(over="red1.left", under="C1.right")
    builder.cap("red1")
    for component in reversed(ordinary):
        builder.cap(component)
    if builder.order:
        raise AssertionError(
            f"layered Hopf-star builder left active strands: {builder.order!r}"
        )
    component_by_piece = {component: component for component in ordinary}
    component_by_piece["red1"] = "red"
    return tuple(builder.forms), component_by_piece


def _semantic_to_topology(lowered: dict, topology) -> dict[str, str]:
    semantics_by_topology: dict[str, set[str]] = defaultdict(set)
    for token, semantic in lowered["semantic_component_by_token"].items():
        semantics_by_topology[topology.component_by_strand[token]].add(semantic)
    if any(len(semantics) != 1 for semantics in semantics_by_topology.values()):
        raise ValueError("side lowering mixed semantic components")
    return {
        next(iter(semantics)): component
        for component, semantics in semantics_by_topology.items()
    }


def _visible_self_writhe(lowered: dict, topology) -> dict[str, int]:
    visible: dict[str, int] = defaultdict(int)
    semantic_by_token = lowered["semantic_component_by_token"]
    for entry in replay_forms(lowered["forms"]):
        form = entry["form"]
        if form["kind"] != "cross":
            continue
        over, under = form["over"], form["under"]
        if semantic_by_token[over] != semantic_by_token[under]:
            continue
        before, after = entry["before_order"], entry["after_order"]
        determinant = (
            topology.strand_orientation(over)
            * topology.strand_orientation(under)
            * (
                after.index(over)
                - before.index(over)
                - after.index(under)
                + before.index(under)
            )
        )
        if determinant == 0:
            raise ValueError("crossing has zero oriented determinant")
        visible[semantic_by_token[over]] += 1 if determinant > 0 else -1
    return dict(visible)


def _vacuum_rank(category, labels: list[int]) -> int:
    reachable = {category.unit: 1}
    for label in labels:
        following: dict[int, int] = defaultdict(int)
        for left, count in reachable.items():
            for output, multiplicity in category.fusion_outputs(left, label):
                following[output] += count * int(multiplicity)
        reachable = dict(following)
    return int(reachable.get(category.unit, 0))


def _replace_projector_with_local_killing_loop(lowered: dict) -> tuple[tuple[dict, ...], dict[str, str]]:
    forms = list(lowered["forms"])
    projector_index = next(
        index for index, form in enumerate(forms) if form["kind"] == "vacuum-projector"
    )
    projector = forms[projector_index]
    trace = replay_forms(forms)
    active = trace[projector_index]["before_order"]
    selected = list(projector["strands"])
    start = active.index(selected[0])
    if active[start : start + len(selected)] != selected:
        raise ValueError("projector interval is not contiguous before local loop insertion")
    cup = {"kind": "cup", "piece": "probe_red1"}
    if start == 0:
        cup["at"] = "far-left"
    else:
        cup["between"] = [active[start - 1], selected[0]]
    local_forms = [cup]
    for token in selected:
        local_forms.append(
            {"kind": "cross", "over": token, "under": "probe_red1.right"}
        )
    for token in reversed(selected):
        local_forms.append(
            {"kind": "cross", "over": "probe_red1.right", "under": token}
        )
    local_forms.append(
        {
            "kind": "cap",
            "piece": "probe_red1",
            "strands": ["probe_red1.left", "probe_red1.right"],
        }
    )
    probe_forms = tuple(forms[:projector_index] + local_forms + forms[projector_index + 1 :])
    if replay_forms(probe_forms)[-1]["after_order"]:
        raise AssertionError("local killing-loop replacement did not close")
    component_by_piece = dict(lowered["component_by_piece"])
    component_by_piece["probe_red1"] = "red"
    return probe_forms, component_by_piece


def evaluate_control(
    control_size: int,
    *,
    family: str = "hopf-star",
    side_projection_angle_degrees: float | None = None,
) -> dict:
    if family == "hopf-star":
        forms, component_by_piece = build_hopf_star(control_size)
        ordinary = tuple(f"C{index}" for index in range(1, control_size + 1))
    elif family == "hopf-winding":
        forms, component_by_piece = build_hopf_winding(control_size)
        ordinary = ("C1",)
        expected_punctures = control_size
    elif family == "two-component-two-round-star":
        forms, component_by_piece = build_layered_hopf_star(2, rounds=2)
        ordinary = ("C1", "C2")
        expected_punctures = 4
    elif family == "two-component-mixed-extra-c1":
        forms, component_by_piece = build_layered_hopf_star(
            2, rounds=1, extra_nearest_windings=1
        )
        ordinary = ("C1", "C2")
        expected_punctures = 3
    else:
        raise ValueError(f"unknown control family {family!r}")
    if family == "hopf-star":
        expected_punctures = control_size
    component_order = ("red", *ordinary)
    framings = {component: 0 for component in component_order}
    category, category_name, category_id = build_restricted_su2_category(3)
    tau = 1
    labels = {component: tau for component in ordinary}

    projected_ir = compile_projected_morphism(
        forms,
        component_by_piece=component_by_piece,
        special_components=("red",),
        component_order=component_order,
    )
    graph = build_vacuum_coupon_graph(forms, projected_ir)
    oracle = RibbonGraphEvaluator(
        category,
        source_forms=forms,
        component_by_piece=component_by_piece,
        projected_ir=projected_ir,
        total_framings=framings,
    )
    oracle_value, oracle_stats = oracle.fixed_label_value(graph, labels)

    lift = build_morse_pl_lift(
        forms,
        component_by_piece=component_by_piece,
        special_components=("red",),
    )
    assignment = optimize_special_disk_sides(lift, "red")
    flattened = build_blockwise_flat_side_lift(
        lift,
        assignment,
        bump_fraction=SIDE_PARAMETERS["bump_fraction"],
        crossing_height_mode=SIDE_PARAMETERS["crossing_height_mode"],
        crossing_margin=SIDE_PARAMETERS["crossing_margin"],
        block_order_strategy=SIDE_PARAMETERS["block_order_strategy"],
        block_order_angle_degrees=SIDE_PARAMETERS["block_order_angle_degrees"],
    )
    side_angle = (
        SIDE_PARAMETERS["side_projection_angle_degrees"]
        if side_projection_angle_degrees is None
        else float(side_projection_angle_degrees)
    )
    side = make_exact_side_projection_lift(flattened, "red", side_angle)
    lowered = lower_exact_side_projection_to_morse(side)
    topology = analyze_topology(lowered["forms"])
    semantic_to_topology = _semantic_to_topology(lowered, topology)
    visible = _visible_self_writhe(lowered, topology)
    topology_labels = {
        semantic_to_topology[component]: label for component, label in labels.items()
    }
    direct_raw_value, direct_stats = MorseEvaluator(category).fixed_label_value(
        tuple(lowered["forms"]), topology_labels
    )
    framing_phase = 1.0 + 0.0j
    for component, label in labels.items():
        framing_phase *= complex(category.twist(label)) ** (-visible.get(component, 0))
    direct_value = direct_raw_value * framing_phase

    probe_forms, probe_component_by_piece = _replace_projector_with_local_killing_loop(
        lowered
    )
    probe_component_order = ("red", *ordinary)
    probe_ir = compile_projected_morphism(
        probe_forms,
        component_by_piece=probe_component_by_piece,
        special_components=("red",),
        component_order=probe_component_order,
    )
    probe_graph = build_vacuum_coupon_graph(probe_forms, probe_ir)
    probe_oracle = RibbonGraphEvaluator(
        category,
        source_forms=probe_forms,
        component_by_piece=probe_component_by_piece,
        projected_ir=probe_ir,
        total_framings={component: 0 for component in probe_component_order},
    )
    local_killing_loop_value, local_killing_loop_stats = (
        probe_oracle.fixed_label_value(probe_graph, labels)
    )

    puncture_count = side["side_projection_source"]["special_disk_intersections"][
        "punctures"
    ]
    puncture_count = len(puncture_count)
    rank = _vacuum_rank(category, [tau] * puncture_count)
    expected_rank = EXPECTED_TAU_VACUUM_RANKS[expected_punctures]
    difference = abs(direct_value - oracle_value)
    coupon = next(
        node for node in graph["nodes"] if node["kind"] == "vacuum-projector-coupon"
    )
    lowered_projector_factors = [
        {
            "token": token,
            "component": lowered["semantic_component_by_token"][token],
            "orientation": topology.strand_orientation(token),
        }
        for token in lowered["projector_order"]
    ]
    twist = complex(category.twist(tau))
    framing_shift_scan = []
    for shift in range(-3, 4):
        shifted = direct_value * twist**shift
        framing_shift_scan.append(
            {
                "additional_twist_power": shift,
                "value": [shifted.real, shifted.imag],
                "absolute_difference": abs(shifted - oracle_value),
            }
        )
    projector_form_index = next(
        index
        for index, form in enumerate(lowered["forms"])
        if form["kind"] == "vacuum-projector"
    )
    attachment_twist_scan = []
    for sign in ("+", "-"):
        variant_forms = list(lowered["forms"])
        variant_forms.insert(
            projector_form_index + 1,
            {
                "kind": "kink",
                "strand": lowered["projector_order"][0],
                "sign": sign,
                "times": 1,
            },
        )
        variant_raw, _variant_stats = MorseEvaluator(category).fixed_label_value(
            tuple(variant_forms), topology_labels
        )
        variant = variant_raw * framing_phase
        attachment_twist_scan.append(
            {
                "diagnostic_only": True,
                "attachment_twist_sign": sign,
                "value": [variant.real, variant.imag],
                "absolute_difference": abs(variant - oracle_value),
            }
        )
    return {
        "family": family,
        "control_size": control_size,
        "component_count": len(component_order),
        "source_crossing_count": sum(form["kind"] == "cross" for form in forms),
        "special_self_crossing_count": 0,
        "puncture_count": puncture_count,
        "expected_puncture_count": expected_punctures,
        "projector_rank": rank,
        "expected_projector_rank": expected_rank,
        "direct_value": [direct_value.real, direct_value.imag],
        "direct_raw_value": [direct_raw_value.real, direct_raw_value.imag],
        "modular_oracle_value": [oracle_value.real, oracle_value.imag],
        "local_killing_loop_value": [
            local_killing_loop_value.real,
            local_killing_loop_value.imag,
        ],
        "local_killing_loop_vs_source_difference": abs(
            local_killing_loop_value - oracle_value
        ),
        "direct_vs_local_killing_loop_difference": abs(
            direct_value - local_killing_loop_value
        ),
        "absolute_difference": difference,
        "value_match": difference <= 1e-8,
        "topology_controls_pass": (
            puncture_count == expected_punctures and rank == expected_rank
        ),
        "visible_self_writhe": visible,
        "framing_phase": [framing_phase.real, framing_phase.imag],
        "framing_shift_scan": framing_shift_scan,
        "attachment_twist_scan": attachment_twist_scan,
        "side_projection_angle_degrees": side_angle,
        "source_coupon_factor_order": _json_safe(coupon.get("factor_order", ())),
        "lowered_projector_factor_order": lowered_projector_factors,
        "lowering_summary": {
            key: lowered[key]
            for key in (
                "crossing_count",
                "projector_factor_count",
                "projector_slice_active_count",
                "projector_routing_crossing_count_each_way",
                "total_routing_crossing_count",
            )
        },
        "direct_stats": _json_safe(direct_stats),
        "oracle_stats": _json_safe(oracle_stats),
        "local_killing_loop_stats": _json_safe(local_killing_loop_stats),
        "category_id": category_id,
        "category_name": category_name,
        "input_hash": stable_json_hash(
            {
                "forms": forms,
                "component_by_piece": component_by_piece,
                "special_components": ["red"],
                "component_order": component_order,
            }
        ),
    }


def main() -> int:
    started = time.perf_counter()
    rows = []
    first_failure = None
    attachment_diagnostics = []
    controls = [
        *(('hopf-star', size) for size in range(1, 6)),
        *(('hopf-winding', size) for size in range(1, 7)),
        ('two-component-two-round-star', 2),
        ('two-component-mixed-extra-c1', 2),
    ]
    for family, control_size in controls:
        row_started = time.perf_counter()
        try:
            row = evaluate_control(control_size, family=family)
            row["elapsed_seconds"] = time.perf_counter() - row_started
        except Exception as exc:  # fail-closed artifact for the first tiny control
            row = {
                "family": family,
                "control_size": control_size,
                "status": "ERROR",
                "error_type": type(exc).__name__,
                "error": str(exc),
                "elapsed_seconds": time.perf_counter() - row_started,
            }
        rows.append(row)
        print(
            json.dumps(
                {
                    key: row.get(key)
                    for key in (
                        "family",
                        "control_size",
                        "puncture_count",
                        "projector_rank",
                        "direct_value",
                        "modular_oracle_value",
                        "absolute_difference",
                        "value_match",
                        "status",
                        "error_type",
                        "error",
                        "elapsed_seconds",
                    )
                    if row.get(key) is not None
                },
                sort_keys=True,
            ),
            flush=True,
        )
        if first_failure is None and (row.get("status") == "ERROR" or not (
            row.get("topology_controls_pass") and row.get("value_match")
        )):
            first_failure = row

    if (
        first_failure is not None
        and first_failure.get("family") == "hopf-winding"
        and first_failure.get("control_size") == 2
    ):
        for angle in (-110.0, -70.0, -20.0, 20.0, 70.0, 110.0, 160.0):
            try:
                row = evaluate_control(
                    2,
                    family="hopf-winding",
                    side_projection_angle_degrees=angle,
                )
                attachment_diagnostics.append(
                    {
                        key: row[key]
                        for key in (
                            "side_projection_angle_degrees",
                            "direct_value",
                            "direct_raw_value",
                            "modular_oracle_value",
                            "absolute_difference",
                            "value_match",
                            "visible_self_writhe",
                            "framing_phase",
                            "source_coupon_factor_order",
                            "lowered_projector_factor_order",
                            "framing_shift_scan",
                            "attachment_twist_scan",
                            "lowering_summary",
                        )
                    }
                )
            except Exception as exc:
                attachment_diagnostics.append(
                    {
                        "side_projection_angle_degrees": angle,
                        "status": "ERROR",
                        "error_type": type(exc).__name__,
                        "error": str(exc),
                    }
                )

    git_commit = subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=REPO, text=True
    ).strip()
    git_status = subprocess.check_output(
        ["git", "status", "--short"], cwd=REPO, text=True
    ).splitlines()
    payload = {
        "schema": "twisted-yetter.special-disk-fibonacci-hopf-star-controls.v1",
        "status": "PASS_ALL_TINY_CONTROLS" if first_failure is None else "FIRST_FAILURE_FOUND",
        "purpose": (
            "Locate the smallest projector valence where geometric side lowering "
            "disagrees with the modular killing-loop oracle."
        ),
        "side_parameters": SIDE_PARAMETERS,
        "expected_tau_vacuum_ranks": EXPECTED_TAU_VACUUM_RANKS,
        "rows": rows,
        "first_failure": first_failure,
        "attachment_diagnostics": attachment_diagnostics,
        "elapsed_seconds": time.perf_counter() - started,
        "generated_at": datetime.now(UTC).isoformat(),
        "git_commit": git_commit,
        "git_dirty": bool(git_status),
        "git_status_short": git_status,
        "generator_script": str(Path(__file__).resolve().relative_to(REPO)),
    }
    OUTPUT.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"status": payload["status"], "output": str(OUTPUT)}))
    return 0 if first_failure is None else 2


if __name__ == "__main__":
    raise SystemExit(main())
