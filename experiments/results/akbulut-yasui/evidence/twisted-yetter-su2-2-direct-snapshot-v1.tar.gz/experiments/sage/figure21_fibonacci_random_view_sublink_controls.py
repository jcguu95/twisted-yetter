#!/usr/bin/env python3
"""Cross-check Figure 21 PL lifts through generic one/two-color views.

Every sector keeps at most two Fibonacci-tau components.  Unit-labeled
components are removed before the PL projection, so all singleton and pair
sublinks can be checked cheaply at several deterministic random viewpoints.
No special-disk projector is used in this control.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
from datetime import UTC, datetime
from itertools import combinations
import json
from pathlib import Path
import random
import shlex
import subprocess
import sys
import time

from experiments.sage.morse_category_registry import build_restricted_su2_category
from experiments.sage.morse_fusion_evaluator import MorseEvaluator, analyze_topology
from experiments.scripts.morse_pl_lift import (
    analyze_projection,
    build_blockwise_flat_side_lift,
    build_morse_pl_lift,
    lower_generic_projection_to_morse,
    make_generic_view_projection_lift,
    optimize_special_disk_sides,
    restrict_pl_lift_components,
)
from experiments.scripts.special_dotted_morphism import replay_forms, stable_json_hash


REPO = Path(__file__).resolve().parents[2]
INPUT = REPO / "experiments/inputs/akbulut-yasui/figure21-right-morse-draft-v1.json"
OUTPUT = Path("/tmp/figure21-fibonacci-random-view-sublink-controls-v1.json")
SEED = 20260714
VIEW_COUNT = 3
TOLERANCE = 1e-8
FLATTENING_PARAMETERS = {
    "bump_fraction": 0.06,
    "crossing_height_mode": "minimal-local",
    "crossing_margin": 0.001,
    "block_order_strategy": "projected-mean-descending",
    "block_order_angle_degrees": 110.0,
}


def semantic_topology_map(forms, semantic_by_strand):
    topology = analyze_topology(forms)
    semantics_by_component = defaultdict(set)
    for strand, component in topology.component_by_strand.items():
        semantics_by_component[component].add(semantic_by_strand[strand])
    ambiguous = {
        component: sorted(semantics)
        for component, semantics in semantics_by_component.items()
        if len(semantics) != 1
    }
    if ambiguous:
        raise ValueError(f"topological components mix semantics: {ambiguous!r}")
    return topology, {
        next(iter(semantics)): component
        for component, semantics in semantics_by_component.items()
    }


def visible_self_writhe(forms, topology, semantic_by_strand):
    visible = defaultdict(int)
    for entry in replay_forms(forms):
        form = entry["form"]
        if form["kind"] != "cross":
            continue
        over, under = form["over"], form["under"]
        over_component = semantic_by_strand[over]
        under_component = semantic_by_strand[under]
        if over_component != under_component:
            continue
        before, after = entry["before_order"], entry["after_order"]
        determinant = (
            topology.strand_orientation(over)
            * topology.strand_orientation(under)
            * (
                after.index(over)
                - before.index(over)
                - after.index(under)
                + before.index(under)
            )
        )
        if determinant == 0:
            raise ValueError("crossing has zero oriented determinant")
        visible[over_component] += 1 if determinant > 0 else -1
    return dict(visible)


def framed_value(
    evaluator,
    category,
    forms,
    semantic_by_strand,
    semantic_labels,
    total_framings,
):
    topology, semantic_to_topology = semantic_topology_map(
        forms, semantic_by_strand
    )
    visible = visible_self_writhe(forms, topology, semantic_by_strand)
    topology_labels = {
        semantic_to_topology[semantic]: label
        for semantic, label in semantic_labels.items()
    }
    value, stats = evaluator.fixed_label_value(forms, topology_labels)
    framing_phase = 1.0 + 0.0j
    for component, label in semantic_labels.items():
        correction = int(total_framings[component]) - visible.get(component, 0)
        framing_phase *= complex(category.twist(label)) ** correction
    return value * framing_phase, {
        "visible_self_writhe": visible,
        "framing_phase": [framing_phase.real, framing_phase.imag],
        "morse": stats,
    }


def source_semantics(source, topology):
    result = {}
    for strand in topology.component_by_strand:
        piece = strand.rsplit(".", 1)[0]
        result[strand] = source["component_by_piece"][piece]
    return result


def deterministic_views(view_count: int):
    generator = random.Random(SEED)
    return [
        {
            "view_id": f"view-{index + 1}",
            "in_plane_angle_degrees": generator.uniform(17.0, 163.0),
            "tilt_degrees": generator.choice((-1.0, 1.0))
            * generator.uniform(5.0, 19.0),
        }
        for index in range(view_count)
    ]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--triple-samples", type=int, default=0)
    parser.add_argument("--triples-only", action="store_true")
    parser.add_argument("--output", type=Path, default=OUTPUT)
    parser.add_argument("--view-count", type=int, default=VIEW_COUNT)
    parser.add_argument(
        "--variant",
        choices=("both", "canonical", "blockwise-29-puncture"),
        default="both",
    )
    args = parser.parse_args()
    if args.triple_samples < 0:
        parser.error("--triple-samples must be nonnegative")
    if args.triples_only and args.triple_samples == 0:
        parser.error("--triples-only requires positive --triple-samples")
    if args.view_count <= 0:
        parser.error("--view-count must be positive")
    started = time.perf_counter()
    started_at = datetime.now(UTC).isoformat()
    source = json.loads(INPUT.read_text())
    forms = tuple(source["forms"])
    source_topology = analyze_topology(forms)
    source_semantic_by_strand = source_semantics(source, source_topology)
    canonical = build_morse_pl_lift(
        forms,
        component_by_piece=source["component_by_piece"],
        special_components=source["special_components"],
    )
    optimization = optimize_special_disk_sides(canonical, "red")
    flattened = build_blockwise_flat_side_lift(
        canonical,
        optimization,
        **FLATTENING_PARAMETERS,
    )
    variants = {"canonical": canonical, "blockwise-29-puncture": flattened}
    if args.variant != "both":
        variants = {args.variant: variants[args.variant]}
    category, category_name, category_id = build_restricted_su2_category(3)
    evaluator = MorseEvaluator(category)
    nontrivial = next(label for label in category.labels if label != category.unit)
    components = tuple(source["component_order"])
    subsets = []
    if not args.triples_only:
        subsets.extend((component,) for component in components)
        subsets.extend(combinations(components, 2))
    available_triples = list(combinations(components, 3))
    if args.triple_samples > len(available_triples):
        parser.error(
            f"--triple-samples exceeds {len(available_triples)} available triples"
        )
    triple_generator = random.Random(SEED + 1)
    triples_with_red = [triple for triple in available_triples if "red" in triple]
    triples_without_red = [
        triple for triple in available_triples if "red" not in triple
    ]
    with_red_count = min((args.triple_samples + 1) // 2, len(triples_with_red))
    without_red_count = args.triple_samples - with_red_count
    selected_triples = triple_generator.sample(triples_with_red, with_red_count)
    selected_triples.extend(
        triple_generator.sample(triples_without_red, without_red_count)
    )
    triple_generator.shuffle(selected_triples)
    subsets.extend(selected_triples)
    views = deterministic_views(args.view_count)
    rows = []
    failures = []

    for subset in subsets:
        full_labels = {component: category.unit for component in components}
        for component in subset:
            full_labels[component] = nontrivial
        expected, expected_stats = framed_value(
            evaluator,
            category,
            forms,
            source_semantic_by_strand,
            full_labels,
            source["framing_labels"],
        )
        retained_labels = {component: nontrivial for component in subset}
        for variant_name, lift in variants.items():
            sublink = restrict_pl_lift_components(lift, subset)
            for view in views:
                viewed = make_generic_view_projection_lift(
                    sublink,
                    in_plane_angle_degrees=view["in_plane_angle_degrees"],
                    tilt_degrees=view["tilt_degrees"],
                )
                projection = analyze_projection(viewed, "xz", max_examples=3)
                if projection["status"] != "PASS_XZ_GENERIC_PROJECTION":
                    raise ValueError(
                        f"nongeneric deterministic view: {subset!r} {view!r} "
                        f"{projection['status']}"
                    )
                lowered = lower_generic_projection_to_morse(viewed)
                observed, observed_stats = framed_value(
                    evaluator,
                    category,
                    tuple(lowered["forms"]),
                    lowered["semantic_component_by_token"],
                    retained_labels,
                    source["framing_labels"],
                )
                difference = abs(observed - expected)
                row = {
                    "subset": list(subset),
                    "subset_size": len(subset),
                    "includes_red": "red" in subset,
                    "variant": variant_name,
                    **view,
                    "expected": [expected.real, expected.imag],
                    "observed": [observed.real, observed.imag],
                    "absolute_difference": difference,
                    "matches": difference <= TOLERANCE,
                    "sublink_hash": sublink["lift_hash"],
                    "viewed_lift_hash": viewed["lift_hash"],
                    "lowering_hash": lowered["lowering_hash"],
                    "lowered_crossing_count": lowered["crossing_count"],
                    "source_stats": expected_stats,
                    "observed_stats": observed_stats,
                }
                rows.append(row)
                if not row["matches"]:
                    failures.append(row)
                    break
            if failures:
                break
        if failures:
            break

    payload = {
        "schema": "twisted-yetter.figure21-fibonacci-random-view-sublink-controls.v1",
        "status": "PASS" if not failures else "FAIL_FIRST_MISMATCH_RECORDED",
        "purpose": (
            "metamorphic check of Morse input -> 3D PL lift -> generic projection; "
            "no special-disk projector is used"
        ),
        "input_path": str(INPUT.relative_to(REPO)),
        "input_hash": stable_json_hash(source),
        "category_id": category_id,
        "category_name": category_name,
        "nontrivial_label": nontrivial,
        "seed": SEED,
        "views": views,
        "variant_hashes": {
            name: lift["lift_hash"] for name, lift in variants.items()
        },
        "singleton_count": sum(len(subset) == 1 for subset in subsets),
        "pair_count": sum(len(subset) == 2 for subset in subsets),
        "triple_count": sum(len(subset) == 3 for subset in subsets),
        "selected_triples": [list(subset) for subset in selected_triples],
        "planned_comparison_count": len(subsets) * len(variants) * len(views),
        "completed_comparison_count": len(rows),
        "maximum_absolute_difference": max(
            (row["absolute_difference"] for row in rows), default=0.0
        ),
        "first_failure": failures[0] if failures else None,
        "tolerance": TOLERANCE,
        "flattening_parameters": FLATTENING_PARAMETERS,
        "started_at": started_at,
        "finished_at": datetime.now(UTC).isoformat(),
        "elapsed_seconds": time.perf_counter() - started,
        "git_commit": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=REPO, text=True
        ).strip(),
        "git_dirty": bool(
            subprocess.check_output(
                ["git", "status", "--porcelain"], cwd=REPO, text=True
            ).strip()
        ),
        "generator_script": str(Path(__file__).resolve().relative_to(REPO)),
        "argv": sys.argv,
        "reproduce_command": "DOT_SAGE=\"$PWD/.sage\" PYTHONPATH=. sage --python "
        + shlex.join(sys.argv),
        "rows": rows,
    }
    temporary = args.output.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    temporary.replace(args.output)
    print(
        json.dumps(
            {
                key: payload[key]
                for key in (
                    "status",
                    "singleton_count",
                    "pair_count",
                    "triple_count",
                    "planned_comparison_count",
                    "completed_comparison_count",
                    "maximum_absolute_difference",
                    "elapsed_seconds",
                    "first_failure",
                )
            },
            indent=2,
            sort_keys=True,
        )
    )
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
