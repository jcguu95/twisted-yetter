#!/usr/bin/env python3
"""Evaluate Figure 21 with the direct side projector in Fibonacci."""

from __future__ import annotations

from collections import Counter, defaultdict
from datetime import UTC, datetime
from itertools import product
import argparse
import json
import math
from pathlib import Path
import subprocess
import sys
import time

from experiments.sage.figure21_su2_2_direct_side_projector import (
    INPUT,
    REPO,
    SIDE_PARAMETERS,
    _semantic_topology_map,
    _visible_self_writhe,
)
from experiments.sage.morse_category_registry import build_restricted_su2_category
from experiments.sage.morse_fusion_evaluator import MorseEvaluator, analyze_topology
from experiments.sage.ribbon_graph_evaluator import RibbonGraphEvaluator
from experiments.scripts.morse_pl_lift import (
    build_blockwise_flat_side_lift,
    build_morse_pl_lift,
    lower_exact_side_projection_to_morse,
    make_exact_side_projection_lift,
    optimize_special_disk_sides,
)
from experiments.scripts.special_dotted_morphism import (
    build_vacuum_coupon_graph,
    compile_projected_morphism,
    stable_json_hash,
)


OUTPUT = Path("/tmp/figure21-fibonacci-direct-side-projector-v1.json")
COMPARISON_OUTPUT = Path(
    "/tmp/figure21-fibonacci-direct-vs-modular-checkpoint-v1.json"
)


def build_context() -> dict:
    source = json.loads(INPUT.read_text())
    forms = tuple(source["forms"])
    lift = build_morse_pl_lift(
        forms,
        component_by_piece=source["component_by_piece"],
        special_components=source["special_components"],
    )
    assignment = optimize_special_disk_sides(lift, "red")
    flattened = build_blockwise_flat_side_lift(
        lift,
        assignment,
        bump_fraction=SIDE_PARAMETERS["bump_fraction"],
        crossing_height_mode=SIDE_PARAMETERS["crossing_height_mode"],
        crossing_margin=SIDE_PARAMETERS["crossing_margin"],
        block_order_strategy=SIDE_PARAMETERS["block_order_strategy"],
        block_order_angle_degrees=SIDE_PARAMETERS["block_order_angle_degrees"],
    )
    side = make_exact_side_projection_lift(
        flattened, "red", SIDE_PARAMETERS["side_projection_angle_degrees"]
    )
    lowered = lower_exact_side_projection_to_morse(side)
    topology = analyze_topology(lowered["forms"])
    semantic_to_topology = _semantic_topology_map(lowered, topology)
    visible_self_writhe, _crossings = _visible_self_writhe(lowered, topology)
    ordinary = tuple(
        component for component in source["component_order"] if component != "red"
    )
    corrections = {
        component: int(source["framing_labels"][component])
        - visible_self_writhe.get(component, 0)
        for component in ordinary
    }
    category, category_name, category_id = build_restricted_su2_category(3)
    original_ir = compile_projected_morphism(
        forms,
        component_by_piece=source["component_by_piece"],
        special_components=source["special_components"],
        component_order=source["component_order"],
    )
    original_graph = build_vacuum_coupon_graph(forms, original_ir)
    oracle = RibbonGraphEvaluator(
        category,
        source_forms=forms,
        component_by_piece=source["component_by_piece"],
        projected_ir=original_ir,
        total_framings=source["framing_labels"],
    )
    return {
        "source": source,
        "side": side,
        "lowered": lowered,
        "topology": topology,
        "semantic_to_topology": semantic_to_topology,
        "visible_self_writhe": visible_self_writhe,
        "framing_corrections": corrections,
        "ordinary": ordinary,
        "category": category,
        "category_name": category_name,
        "category_id": category_id,
        "evaluator": MorseEvaluator(category),
        "oracle": oracle,
        "oracle_graph": original_graph,
    }


def projector_rank(context: dict, labels: dict[str, int]) -> int:
    category = context["category"]
    reachable = {category.unit: 1}
    for token in context["lowered"]["projector_order"]:
        label = labels[context["lowered"]["semantic_component_by_token"][token]]
        if context["topology"].strand_orientation(token) < 0:
            label = category.dual(label)
        following: dict[int, int] = defaultdict(int)
        for left, count in reachable.items():
            for output, multiplicity in category.fusion_outputs(left, label):
                following[output] += count * int(multiplicity)
        reachable = dict(following)
    return int(reachable.get(category.unit, 0))


def fixed_value(context: dict, labels: dict[str, int]) -> tuple[complex, dict]:
    topology_labels = {
        context["semantic_to_topology"][semantic]: label
        for semantic, label in labels.items()
    }
    value, stats = context["evaluator"].fixed_label_value(
        tuple(context["lowered"]["forms"]), topology_labels
    )
    framing_phase = 1.0 + 0.0j
    for component, label in labels.items():
        framing_phase *= complex(context["category"].twist(label)) ** context[
            "framing_corrections"
        ][component]
    return value * framing_phase, stats


def write_checkpoint(context: dict, records: list[dict], started: float) -> None:
    partial = sum(
        complex(*record["weighted_contribution"])
        for record in records
        if record["status"] == "EVALUATED"
    )
    payload = {
        "schema": "twisted-yetter.figure21-fibonacci-direct-side-projector.v1",
        "status": "RUNNING" if len(records) < 2048 else "COMPLETE",
        "category_id": context["category_id"],
        "category_name": context["category_name"],
        "input_hash": stable_json_hash(context["source"]),
        "side_lift_hash": context["side"]["lift_hash"],
        "lowering_hash": context["lowered"]["lowering_hash"],
        "side_parameters": SIDE_PARAMETERS,
        "lowering_summary": {
            key: context["lowered"][key]
            for key in (
                "crossing_count",
                "projector_factor_count",
                "projector_slice_active_count",
                "projector_routing_crossing_count_each_way",
                "total_routing_crossing_count",
            )
        },
        "ordinary_component_order": list(context["ordinary"]),
        "visible_self_writhe": context["visible_self_writhe"],
        "framing_corrections": context["framing_corrections"],
        "completed_sector_count": len(records),
        "partial_weighted_sum": [partial.real, partial.imag],
        "elapsed_seconds": time.perf_counter() - started,
        "records": records,
        "updated_at": datetime.now(UTC).isoformat(),
        "generator_script": str(Path(__file__).resolve().relative_to(REPO)),
    }
    temporary = OUTPUT.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    temporary.replace(OUTPUT)


def compare_checkpoint(
    *,
    limit: int | None = None,
    exact_weight: int | None = None,
    min_projector_rank: int | None = None,
    max_projector_rank: int | None = None,
    one_per_projector_rank: bool = False,
    output: Path = COMPARISON_OUTPUT,
) -> int:
    started = time.perf_counter()
    checkpoint = json.loads(OUTPUT.read_text())
    context = build_context()
    rows = []
    mismatches = []
    assignments = sorted(
        product(context["category"].labels, repeat=len(context["ordinary"])),
        key=lambda labels: (
            sum(label != context["category"].unit for label in labels),
            labels,
        ),
    )
    selected = []
    seen_ranks = set()
    for label_tuple in assignments:
        labels = dict(zip(context["ordinary"], label_tuple, strict=True))
        weight = sum(
            label != context["category"].unit for label in label_tuple
        )
        if exact_weight is not None and weight != exact_weight:
            continue
        rank = projector_rank(context, labels)
        if min_projector_rank is not None and rank < min_projector_rank:
            continue
        if max_projector_rank is not None and rank > max_projector_rank:
            continue
        if one_per_projector_rank and rank in seen_ranks:
            continue
        seen_ranks.add(rank)
        selected.append((label_tuple, rank))
    selected.sort(key=lambda item: (item[1], item[0]))
    if limit is not None:
        selected = selected[:limit]
    for sector_index, (label_tuple, rank) in enumerate(selected):
        labels = dict(zip(context["ordinary"], label_tuple, strict=True))
        row_started = time.perf_counter()
        if rank == 0:
            direct_value = 0.0 + 0.0j
        else:
            direct_value, _direct_stats = fixed_value(context, labels)
        oracle_value, _stats = context["oracle"].fixed_label_value(
            context["oracle_graph"], labels
        )
        difference = abs(direct_value - oracle_value)
        row = {
            "checkpoint_index": sector_index,
            "labels": list(label_tuple),
            "projector_rank": rank,
            "direct_value": [direct_value.real, direct_value.imag],
            "modular_oracle_value": [oracle_value.real, oracle_value.imag],
            "absolute_difference": difference,
            "matches": difference <= 1e-8,
            "elapsed_seconds": time.perf_counter() - row_started,
        }
        rows.append(row)
        print(json.dumps(row, sort_keys=True), flush=True)
        if not row["matches"]:
            mismatches.append(row)
    payload = {
        "schema": "twisted-yetter.figure21-fibonacci-direct-vs-modular-checkpoint.v1",
        "status": "PASS" if not mismatches else "MISMATCH",
        "source_checkpoint": str(OUTPUT),
        "source_completed_sector_count": checkpoint["completed_sector_count"],
        "assignment_source": "fresh-hamming-weight-then-lexicographic-enumeration",
        "compared_sector_count": len(rows),
        "tolerance": 1e-8,
        "requested_comparison_count": limit,
        "selection": {
            "exact_weight": exact_weight,
            "min_projector_rank": min_projector_rank,
            "max_projector_rank": max_projector_rank,
            "one_per_projector_rank": one_per_projector_rank,
            "selected_projector_ranks": [rank for _labels, rank in selected],
        },
        "mismatch_count": len(mismatches),
        "first_mismatch": mismatches[0] if mismatches else None,
        "rows": rows,
        "elapsed_seconds": time.perf_counter() - started,
        "finished_at": datetime.now(UTC).isoformat(),
    }
    output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    print(
        json.dumps(
            {
                "status": payload["status"],
                "compared": len(rows),
                "elapsed_seconds": payload["elapsed_seconds"],
                "output": str(output),
            },
            sort_keys=True,
        )
    )
    return 0 if not mismatches else 2


def write_projector_rank_summary(output: Path) -> int:
    """Record the complete combinatorial projector-rank landscape."""
    started = time.perf_counter()
    context = build_context()
    category = context["category"]
    ranks_by_weight: dict[int, list[int]] = defaultdict(list)
    for label_tuple in product(
        category.labels, repeat=len(context["ordinary"])
    ):
        labels = dict(zip(context["ordinary"], label_tuple, strict=True))
        weight = sum(label != category.unit for label in label_tuple)
        ranks_by_weight[weight].append(projector_rank(context, labels))

    rows = []
    for weight in sorted(ranks_by_weight):
        ranks = sorted(ranks_by_weight[weight])
        histogram = Counter(ranks)
        rows.append(
            {
                "hamming_weight": weight,
                "sector_count": len(ranks),
                "zero_rank_sector_count": histogram.get(0, 0),
                "minimum_projector_rank": ranks[0],
                "maximum_projector_rank": ranks[-1],
                "median_projector_rank": ranks[len(ranks) // 2],
                "projector_rank_histogram": {
                    str(rank): count for rank, count in sorted(histogram.items())
                },
            }
        )

    git_commit = subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=REPO, text=True
    ).strip()
    git_status = subprocess.check_output(
        ["git", "status", "--short"], cwd=REPO, text=True
    ).strip()
    payload = {
        "schema": "twisted-yetter.figure21-fibonacci-projector-rank-summary.v1",
        "status": "COMPLETE_COMBINATORIAL_SCAN",
        "purpose": (
            "Rank the direct special-disk projector workload before numerical "
            "contraction; this is not an RT evaluation result."
        ),
        "input_path": str(INPUT.relative_to(REPO)),
        "input_hash": stable_json_hash(context["source"]),
        "category_id": context["category_id"],
        "category_name": context["category_name"],
        "ordinary_component_order": list(context["ordinary"]),
        "sector_count": len(category.labels) ** len(context["ordinary"]),
        "maximum_projector_rank": max(
            row["maximum_projector_rank"] for row in rows
        ),
        "rows": rows,
        "elapsed_seconds": time.perf_counter() - started,
        "finished_at": datetime.now(UTC).isoformat(),
        "repo_root": str(REPO),
        "git_commit": git_commit,
        "git_dirty": bool(git_status),
        "git_status_short": git_status.splitlines(),
        "generator_script": str(Path(__file__).resolve().relative_to(REPO)),
        "argv": [str(argument) for argument in sys.argv],
        "reproduce_command": (
            'DOT_SAGE="$PWD/.sage" PYTHONPATH=. sage --python '
            "experiments/sage/figure21_fibonacci_direct_side_projector.py "
            f"--rank-summary-output {output}"
        ),
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(output.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    temporary.replace(output)
    print(
        json.dumps(
            {
                "status": payload["status"],
                "sector_count": payload["sector_count"],
                "maximum_projector_rank": payload["maximum_projector_rank"],
                "elapsed_seconds": payload["elapsed_seconds"],
                "output": str(output),
            },
            sort_keys=True,
        )
    )
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--compare-checkpoint", action="store_true")
    parser.add_argument("--compare-count", type=int)
    parser.add_argument("--compare-exact-weight", type=int)
    parser.add_argument("--compare-min-projector-rank", type=int)
    parser.add_argument("--compare-max-projector-rank", type=int)
    parser.add_argument("--compare-one-per-projector-rank", action="store_true")
    parser.add_argument("--compare-output", type=Path, default=COMPARISON_OUTPUT)
    parser.add_argument("--rank-summary-output", type=Path)
    args = parser.parse_args()
    if args.rank_summary_output is not None:
        return write_projector_rank_summary(args.rank_summary_output)
    if args.compare_checkpoint:
        if args.compare_count is not None and args.compare_count <= 0:
            parser.error("--compare-count must be positive")
        return compare_checkpoint(
            limit=args.compare_count,
            exact_weight=args.compare_exact_weight,
            min_projector_rank=args.compare_min_projector_rank,
            max_projector_rank=args.compare_max_projector_rank,
            one_per_projector_rank=args.compare_one_per_projector_rank,
            output=args.compare_output,
        )
    started = time.perf_counter()
    context = build_context()
    category = context["category"]
    assignments = sorted(
        product(category.labels, repeat=len(context["ordinary"])),
        key=lambda labels: (sum(label != category.unit for label in labels), labels),
    )
    records = []
    for sector_index, label_tuple in enumerate(assignments):
        labels = dict(zip(context["ordinary"], label_tuple, strict=True))
        rank = projector_rank(context, labels)
        row_started = time.perf_counter()
        if rank == 0:
            record = {
                "labels": list(label_tuple),
                "projector_rank": 0,
                "status": "PRUNED_NO_VACUUM",
                "raw_value": [0.0, 0.0],
                "kirby_weight": 1.0,
                "weighted_contribution": [0.0, 0.0],
                "elapsed_seconds": time.perf_counter() - row_started,
            }
        else:
            value, stats = fixed_value(context, labels)
            weight = math.prod(float(category.dimension(label)) for label in label_tuple)
            contribution = weight * value
            record = {
                "labels": list(label_tuple),
                "projector_rank": rank,
                "status": "EVALUATED",
                "raw_value": [value.real, value.imag],
                "kirby_weight": weight,
                "weighted_contribution": [contribution.real, contribution.imag],
                "elapsed_seconds": time.perf_counter() - row_started,
                "evaluator_stats": stats,
            }
        records.append(record)
        if len(records) <= 10 or len(records) % 25 == 0:
            write_checkpoint(context, records, started)
            print(
                json.dumps(
                    {
                        "completed": len(records),
                        "last_projector_rank": rank,
                        "last_elapsed_seconds": record["elapsed_seconds"],
                        "total_elapsed_seconds": time.perf_counter() - started,
                    },
                    sort_keys=True,
                ),
                flush=True,
            )
    write_checkpoint(context, records, started)
    payload = json.loads(OUTPUT.read_text())
    figure_value = complex(*payload["partial_weighted_sum"])
    p_plus = sum(
        complex(category.dimension(label)) ** 2 * complex(category.twist(label))
        for label in category.labels
    )
    p_minus = sum(
        complex(category.dimension(label)) ** 2 / complex(category.twist(label))
        for label in category.labels
    )
    standard = p_plus * p_minus**9
    payload.update(
        {
            "status": "PASS" if abs(figure_value - standard) <= 1e-8 else "NO_MATCH",
            "figure21_value": [figure_value.real, figure_value.imag],
            "standard_cp2_9cpbar_value": [standard.real, standard.imag],
            "absolute_difference": abs(figure_value - standard),
            "match": abs(figure_value - standard) <= 1e-8,
            "git_commit": subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=REPO, text=True
            ).strip(),
            "git_dirty": bool(
                subprocess.check_output(
                    ["git", "status", "--short"], cwd=REPO, text=True
                ).strip()
            ),
        }
    )
    OUTPUT.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    print(
        json.dumps(
            {
                "status": payload["status"],
                "figure21_value": payload["figure21_value"],
                "standard_value": payload["standard_cp2_9cpbar_value"],
                "absolute_difference": payload["absolute_difference"],
                "elapsed_seconds": payload["elapsed_seconds"],
                "output": str(OUTPUT),
            },
            indent=2,
            sort_keys=True,
        )
    )
    return 0 if payload["match"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
